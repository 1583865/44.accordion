$(".list").click(function(){
	$(this).addClass("show").siblings().removeClass("show");

});